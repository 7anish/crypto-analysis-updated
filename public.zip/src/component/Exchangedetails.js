import React from 'react'

const Exchangedetails = () => {
  return (
    <div>
      exchanhgedetails
    </div>
  )
}

export default Exchangedetails
